<?php
require_once($CFG->libdir . '/formslib.php');

class local_predictor_upload_form extends moodleform {
    public function definition() {
        $mform = $this->_form;

        $mform->addElement('filepicker', 'csvfile', 'Selecciona el archivo CSV', null, ['accepted_types' => '.csv']);
        $mform->addRule('csvfile', 'Requerido', 'required', null, 'client');

        $mform->addElement('advcheckbox', 'hideids', 'Ocultar ID de Estudiante en resultados');

        $this->add_action_buttons(true, 'Enviar');
    }
}
