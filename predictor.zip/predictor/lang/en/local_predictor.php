<?php
$string['pluginname'] = 'Predictor Limpio';