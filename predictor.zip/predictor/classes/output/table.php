<?php
defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/tablelib.php');

class local_predictor_table extends flexible_table {

    public function __construct($uniqueid) {
        parent::__construct($uniqueid);

        $this->define_columns(['id_estudiante', 'prediccion', 'confianza']);
        $this->define_headers(['ID Estudiante', 'Predicción', 'Confianza']);

        $this->setup();
    }

    public function build_table() {
        $session = $_SESSION;
        $hideids = $session['predictor_hideids'] ?? 0;

        if (!empty($session['predictor_resultados'])) {
            $counter = 1;
            foreach ($session['predictor_resultados'] as $row) {
                $idestudiante = $hideids ? 'Estudiante ' . $counter : ($row['id_estudiante'] ?? '-');
                $prediccion = $row['prediccion'] ?? '-';
                $confianza = $row['confianza'] ?? '-';

                $this->add_data([$idestudiante, $prediccion, $confianza]);
                $counter++;
            }
        }
    }
}
