<?php
require_once(__DIR__.'/../../config.php');
require_login();

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Si hay acciones de limpiar
if (optional_param('clear', 0, PARAM_INT)) {
    unset($_SESSION['predictor_resultados']);
    unset($_SESSION['predictor_json']);
    unset($_SESSION['predictor_hideids']);
    redirect(new moodle_url('/local/predictor/index.php'));
}

// Si descarga CSV
if (optional_param('download', '', PARAM_ALPHA) === 'csv' && !empty($_SESSION['predictor_resultados'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="predicciones.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID Estudiante', 'Predicción', 'Confianza']);

    foreach ($_SESSION['predictor_resultados'] as $row) {
        fputcsv($output, [$row['id_estudiante'], $row['prediccion'], $row['confianza']]);
    }

    fclose($output);
    exit;
}

$PAGE->set_url(new moodle_url('/local/predictor/index.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title('Resultados de Predicción');
$PAGE->set_heading('Resultados de Predicción');

echo $OUTPUT->header();

require_once('upload_form.php');
$mform = new local_predictor_upload_form();

// ✅ PROCESAR FORMULARIO
if ($mform->is_cancelled()) {
    redirect(new moodle_url('/local/predictor/index.php'));
} elseif ($data = $mform->get_data()) {

    // ✅ Limpiar datos anteriores:
    unset($_SESSION['predictor_resultados']);
    unset($_SESSION['predictor_json']);
    $_SESSION['predictor_hideids'] = $data->hideids ?? 0;

    // ✅ Procesar archivo:
    $draftitemid = file_get_submitted_draft_itemid('csvfile');
    $fs = get_file_storage();
    $files = $fs->get_area_files(context_user::instance($USER->id)->id, 'user', 'draft', $draftitemid, 'id DESC', false);

    if (!empty($files)) {
        $file = reset($files);
        $content = $file->get_content();
        $filename = $file->get_filename();

        $tempfile = tempnam(sys_get_temp_dir(), 'predictor_');
        file_put_contents($tempfile, $content);

        $ch = curl_init();
        $postdata = ['file' => new CURLFile($tempfile, 'text/csv', $filename)];
        curl_setopt($ch, CURLOPT_URL, 'http://127.0.0.1:5000/evaluar?incluir_id=true');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        $response = curl_exec($ch);
        curl_close($ch);

        unlink($tempfile);

        $resultados = json_decode($response, true);

        if (!empty($resultados['resultados'])) {
            $_SESSION['predictor_resultados'] = $resultados['resultados'];
            $_SESSION['predictor_json'] = $response;

            // ✅ Mostrar tabla inmediatamente después
        } else {
            echo $OUTPUT->notification('No se recibieron resultados.', 'notifyproblem');
        }
    }
}

// ✅ BOTONES de LIMPIAR / DESCARGAR
if (!empty($_SESSION['predictor_resultados'])) {
    $clearurl = new moodle_url('/local/predictor/index.php', ['clear' => 1]);
    $downloadurl = new moodle_url('/local/predictor/index.php', ['download' => 'csv']);

    echo html_writer::start_div('buttons-actions', ['style' => 'margin-bottom: 20px;']);
    echo html_writer::link($clearurl, '🗑️ Limpiar Resultados', ['class' => 'btn btn-danger', 'style' => 'margin-right: 10px;']);
    echo html_writer::link($downloadurl, '⬇️ Descargar CSV', ['class' => 'btn btn-primary']);
    echo html_writer::end_div();

    // ✅ Mostrar tabla
    require_once('classes/output/table.php');
    $table = new local_predictor_table('resultados');
    $table->build_table();
    $table->print_html();

    // ✅ Mostrar JSON en bruto (debug visual)
    echo $OUTPUT->notification('<pre>' . htmlspecialchars($_SESSION['predictor_json']) . '</pre>', 'notifymessage');
}

$mform->display();

echo $OUTPUT->footer();
