<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_predictor';
$plugin->version = 2025064000;
$plugin->requires = 2021051700;
